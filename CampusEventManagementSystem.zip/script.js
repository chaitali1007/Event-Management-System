
document.addEventListener('DOMContentLoaded', () => {
    fetch('events.php?type=upcoming')
        .then(res => res.json())
        .then(data => {
            document.getElementById('upcoming-events').innerHTML =
                data.map(e => `<div><strong>${e.title}</strong><br>${e.date}</div>`).join('');
        });

    fetch('events.php?type=past')
        .then(res => res.json())
        .then(data => {
            document.getElementById('past-events').innerHTML =
                data.map(e => `
                    <div>
                        <strong>${e.title}</strong><br>
                        ${e.date}<br>
                        ${e.winner ? '<em>Winner: ' + e.winner + '</em>' : ''}
                    </div>
                `).join('');
        });
});
