<?php
$events = [
    ["title" => "Hackathon 2025", "date" => "2025-09-15"],
    ["title" => "Cultural Fest", "date" => "2025-07-10", "winner" => "Team B"],
    ["title" => "Tech Talk", "date" => "2025-06-01", "winner" => "Speaker: Dr. Kumar"]
];

$type = $_GET['type'];
$today = date("Y-m-d");

$filtered = array_filter($events, function($event) use ($type, $today) {
    return $type == 'upcoming' ? $event['date'] >= $today : $event['date'] < $today;
});

header('Content-Type: application/json');
echo json_encode(array_values($filtered));
?>
