<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $eventTitle = $_POST["event_title"];
    $winner = $_POST["winner"];
    $data = json_decode(file_get_contents("events.json"), true);
    foreach ($data as &$event) {
        if ($event["title"] == $eventTitle) {
            $event["winner"] = $winner;
        }
    }
    file_put_contents("events.json", json_encode($data, JSON_PRETTY_PRINT));
    header("Location: admin.php");
    exit;
}
$events = json_decode(file_get_contents("events.json"), true);
?>
<h2>Update Winners</h2>
<form method="POST">
    <select name="event_title">
        <?php foreach ($events as $e): ?>
            <?php if ($e["date"] < date("Y-m-d")): ?>
                <option value="<?= $e['title'] ?>"><?= $e['title'] ?></option>
            <?php endif; ?>
        <?php endforeach; ?>
    </select>
    <input type="text" name="winner" placeholder="Winner name">
    <input type="submit" value="Update">
</form>
<h2>Event Registrations</h2>
<ul>
<?php
$registrations = file_exists("registrations.txt") ? file("registrations.txt") : [];
foreach ($registrations as $r) {
    echo '<li>' . htmlspecialchars($r) . '</li>';
}
?>
</ul>
