<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $event = $_POST["event"];
    file_put_contents("registrations.txt", "$name - $event\n", FILE_APPEND);
    echo "Registration successful!";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<h2>Register for an Event</h2>
<form method="POST">
    Name: <input type="text" name="name" required><br>
    Event: <input type="text" name="event" required><br>
    <input type="submit" value="Register">
</form>
</body>
</html>
